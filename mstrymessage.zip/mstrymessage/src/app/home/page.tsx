import React from 'react'

const page = () => {
  return (
    <div>Home page</div>
  )
}

export default page
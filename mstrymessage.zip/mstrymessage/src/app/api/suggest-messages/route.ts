//import { openai } from '@ai-sdk/openai';
import { OpenAIStream, StreamingTextResponse } from 'ai';
import { NextResponse } from 'next/server';
import OpenAI from 'openai';
import { text } from 'stream/consumers';

// Allow streaming responses up to 30 seconds
//export const maxDuration = 30;
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
})

export async function POST(req: Request) {
  try {
    //const { messages } = await req.json();
    //  const prompt = "Create a list of three open-ended and engaging questions formatted as a single string. Each question should be seperated by '||'. These questions are for an anonymous social messaging platform, like Qooh.me, and should be suitable for a diverse audience. Avoid personal or sensitive topics, focusing instead on universal themes that encourage fiendly interaction. For example, your output should be structured like this: 'What's a hoby you've recently started?||If you could have dinner with any historical figure, who would it be?|What's a simple thing that makes you happy?'. Ensure the questions are intriguing, foster curiosity, and contribute to a positive and welcoming conversational environment."
     const prompt = "tell me a joke of 100 words"
    // const result = await streamText({
    //   model: openai('gpt-3.5-turbo-instruct'),
    //   prompt: prompt,
    // });
   const response = await openai.completions.create({
    model: 'gpt-3.5-turbo',
    stream: true,
    prompt,
   })

    //  const result = await streamText({
    //   model: openai('gpt-3.5-turbo-instruct'),
    //   maxTokens: 400,
    //   prompt: prompt,
    //   //temperature: 0.3,
    //  // maxRetries: 5,
    // });
    const stream = OpenAIStream(response)
     //console.log('result', result)
    
    return new StreamingTextResponse(stream)
  } catch (error) {
    if (error instanceof OpenAI.APIError) {
        const {name, status, headers, message} = error
        return NextResponse.json({
            name, status, headers, message
        }, {status})
    } else {
        console.error("An unexpected error occured")
        throw error

    }
  }
}
import dbConnect from "@/lib/dbConnect";
import UserModel from "@/model/User.model";
// import {z} from "zod";

// import { usernameValidation } from "@/schemas/signUpSchema";

export async function POST(request: Request){
    await dbConnect()

    try {
       const {username, code}  = await request.json()
       const decodedUsername = decodeURIComponent(username)
       const user = await UserModel.findOne({username: decodedUsername})
       if(!user){
        return Response.json(
            {
                success : false,
                message: "User not found"
            },
            {status: 500}
        ) 
       }

       const isCodeValid = user.verifyCode === code
       const isCodeNoteExpired = new Date(user.verifyCodeExpiry) > new Date()
       if(isCodeValid && isCodeNoteExpired){
        user.isVerified = true
        await user.save()
        return Response.json(
            {
                success : true,
                message: "Account verified successfully"
            },
            {status: 200}
        ) 
       } else if(!isCodeNoteExpired){
        return Response.json(
            {
                success : false,
                message: "Verification code has expired please signup again to get a new code"
            },
            {status: 200}
        )
       } else {
        return Response.json(
            {
                success : false,
                message: "Incorrect Verification code"
            },
            {status: 200}
        )
       }
       
       
    } catch (error) {
        console.error("Error verifying username", error)
        return Response.json(
            {
                success : false,
                message: "Error verifying username"
            },
            {status: 500}
        ) 
    }
}
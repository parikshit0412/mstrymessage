import React from 'react'

const page = () => {
  return (
    <div>message page</div>
  )
}

export default page